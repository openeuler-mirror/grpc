gRPC Admin
==========

What is gRPC Admin?
---------------------------------------------

It's a convenient API to improve the usability of creating a gRPC server with admin services to expose states in the gRPC library.

Design Document `gRPC Admin Interface <https://github.com/grpc/proposal/blob/master/A38-admin-interface-api.md>`_

Module Contents
---------------

.. automodule:: grpc_admin
